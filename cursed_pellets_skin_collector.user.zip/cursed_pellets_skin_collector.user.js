// ==UserScript==
// @name         Cursed Pellets: Skin Collector NTL VER 7.29
// @namespace    http://tampermonkey.net/
// @version      1
// @description  Capture and record player skins
// @author       Cursed Pellets
// @match        http://slither.io/
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
// ********** SCROLL TO LINE 285 FOR AREAS OF UPDATING AND MAKING CHANGES, INSTRUCTIONS *******************************
// CHANGE KEY BINDINGS STARTING ON LINE 390
// LINE 402 STARTS AUTOMATION CODE - IT IS COMMENTED OUT WITH 2 FORWARD SLASHES, REMOVE SLASHES TO AUTOMATE HANDS FREE CAPTURING
var launcherDiv = document.createElement("div");
launcherDiv.innerHTML = `
<style>
.navbar {
  display: none;
  overflow: hidden;
  background-color: #333;
  position: fixed;
  bottom: 0;
  width: 15%;
  z-index: 9999;
  opacity: 0.9;
}
.navbar a {
  float: left;
  display: block;
  color: white;
  text-align: center;
  padding: 5px 5px;
  text-decoration: none;
  font-size: 10px;
  background: #000000;
}

.navbar a:hover {
  background: #000000;
  color: white;
}

.navbar a.active {
  background-color: #000000;
  color: white;
}

.main {
  padding: 16px;
  margin-bottom: 30px;
}
</style>
<div class="navbar">
  <a href="#launcher" id="skinLogLauncher">Show Logged Skins<br>'W' to capture skins.<br>" \` " to clear screen.</a>
  <p class="title">Skin Collector Launcher</p>
</div>
`
// Add launcher to page
document.body.appendChild(launcherDiv);
// Get launcher link
const launcherLink = document.getElementById("skinLogLauncher");
// Launch page when clicked
launcherLink.addEventListener("click", () => createPlayerSkinPage());
//Hide skin log page



function createPlayerSkinPage(){
var naswInnerHTML = `
<style>
#nameAndSkinWrapper{

overflow-y: auto;
background-color: black;
z-index: 9999999999;
width: 100%;
height: 100%;
display: block;
position: fixed;
}
.player-info{
display:inline-block;
width: 25%;
inline-size: 450px;
overflow-wrap: break-word;
border-color: #99999999;
}
.playerName{
color: lime;
}
.playerSkin{
color: pink;
}
#skinlog_title{
top: 0px;
width: 100%;
color: white;
size: 12;
text-align: center;
border-color: #999999;
}
</style>
<div id="skinlog_title">
<a href="#hide_skinlog" id="skinlogHider"></a>
</div>
`
const PlayerDataDivWrapper = document.getElementById('PlayerDataDivWrapper');
PlayerDataDivWrapper.style.visibility = 'hidden';


//************* 1ST REFERENCE TO LOCAL STORAGE
let storedDictionary = JSON.parse(localStorage.getItem('enemyNameSkinDictionary'));
//************* 1ST REFERENCE TO LOCAL STORAGE

var doesNASWexist = document.getElementById("nameAndSkinWrapper");
var nameAndSkinWrapper
if (doesNASWexist === null){
     nameAndSkinWrapper = document.createElement("div");

    nameAndSkinWrapper.setAttribute("id","nameAndSkinWrapper");
    nameAndSkinWrapper.innerHTML = naswInnerHTML;
    // Dynamically create HTML and add player: skin to page
    document.body.appendChild(nameAndSkinWrapper);
} else {
    nameAndSkinWrapper = document.getElementById("nameAndSkinWrapper");
    nameAndSkinWrapper.innerHTML = naswInnerHTML;
    nameAndSkinWrapper.style.visibility = "visible";
}

var skinlogHider = document.getElementById("skinlogHider");
// Hide Page when clicked
skinlogHider.addEventListener("click", function (){
    nameAndSkinWrapper.style.visibility = "hidden";
});


//******************* 2ND REFERRENCE TO LOCAL STORAGE - ACCESSSING BUT NOT CHANGING DATA
for (let key in storedDictionary) {
  let playerName = document.createElement('span');
  playerName.className = 'playerName';
  playerName.textContent = key + ": ";

  let playerSkin = document.createElement('span');
  playerSkin.className = 'playerSkin';
  playerSkin.textContent = storedDictionary[key];

  let player = document.createElement('div');
  // Add a class to the player div so we can change styles with CSS later
  player.className = 'player-info';
  player.appendChild(playerName);
  player.appendChild(playerSkin);

  nameAndSkinWrapper.appendChild(player);
}

}
// End of function

var nonameCounter = 0;
// Dictionary builder for name and skin - saves to local storage.
function addToDictionary(name, skin) {
  let key = name || `Noname ${nonameCounter}`;

  // Retrieve existing data from local storage
  let enemyNameSkinDict = JSON.parse(localStorage.getItem('enemyNameSkinDictionary')) || {};

  if (!enemyNameSkinDict[key]) {
    enemyNameSkinDict[key] = skin;

    // Store the updated data back into local storage
    localStorage.setItem('enemyNameSkinDictionary', JSON.stringify(enemyNameSkinDict));

    if (!name) {
      nonameCounter++;
    }
  } else {
    console.log(`Error: An entry with the name "${key}" already exists.`);
  }
}

const skin_dict={
"27":["1"],
"28":["2"],
"29":["3"],
"30":["4"],
"31":["5"],
"32":["6"],
"33":["7"],
"34":["8"],
"35":["9"],
"36":["Special: 36"],
"37":["0"],
"38":["Special: 38"],
"39":["-"],
"40":["Special: 40"],
"17":["q"],
"18":["w"],
"19":["e"],
"20":["r"],
"21":["t"],
"22":["y"],
"23":["u"],
"24":["i"],
"25":["o"],
"26":["p"],
"8":["a"],
"9":["s"],
"10":["d"],
"11":["f"],
"12":["g"],
"13":["h"],
"14":["j"],
"15":["k"],
"16":["l"],
"0":["z"],
"1":["x"],
"2":["c"],
"3":["v"],
"4":["b"],
"5":["n"],
"6":["m"],
"7":[","]
};

const PlayerDataDivWrapperInnerHTML = `
<style>
#PlayerDataDiv {
pointer-events: none;
background-color: transparent;
inline-size: 200px;
overflow-wrap: break-word;
left: 0px;
top: 50px;
text-align: left;
z-index: 9999999999999999999;
width: 25%;
height: 80%;
opacity: 0.8;
position: absolute;
font-size: 10px;
}
#topDiv{
pointer-events: none;
text-align: center;
font-size: 11px;
color: red;
}
a {
color: red;
}
.snakeName{
color: lime;
}
.snakeSkin{
color: pink;
}
#larger{
font-size: 16px;
}
#ShowHideText{
pointer-events: none;
color: red;
display: none;
}
</style>
<div id="PlayerDataDiv">
<div id="topDiv">
<span id="ShowHideText">***Skins Captured***</span>
</div>

</div>
`;
var newDiv = document.createElement("div");
newDiv.setAttribute("id","PlayerDataDivWrapper");
newDiv.innerHTML = PlayerDataDivWrapperInnerHTML;
document.body.appendChild(newDiv);
document.getElementById("PlayerDataDivWrapper").style.visibility = "hidden";


function clearSkinDataDiv(){
console.log("Clicked");
document.getElementById("PlayerDataDivWrapper").innerHTML = PlayerDataDivWrapperInnerHTML;
}

let keys = [];
let newPlayersArray = [];
let playerDataArray = [];
var skinList = [];
var skinString = "";
var keyList = [];
var dictKeys = "";
var value = "";
var addBreak = false;
var pageClearCounter = 0;
function getAndDisplayPlayerData() {




//***************************************************************************************************************************************
// ********** START CHANGES HERE AFTER NTL UPDATES *******************
//***************************************************************************************************************************************

// Find object array from developer console of browser.
// Player object array is global an will be find by searching through all global objects by typing "window" into dev console.
// Will be full of objects with unique ID starting with "s"
// Example: 1. s5569, 2.s3245, 3.s93839, 4.s3232
// Change object 'window.bn' to whatever player object array is at this point. IE: if you see fG:  {1. s5569, 2.s3245, 3.s93839, 4.s3232}
// your object would be 'window.fG' now.

// Expand player object, search for IGN variable. Do not use the one with "@" symbol.
// Dropdown an ID and it will have variables & objects.
// IGN variable will look something like 'xX: "[WORM] Pellets"'. 'xX' is the variable.
// Look for skin array, this can be tricky if you're unfamiliar.
// It will look something like 'yY: [10,5,10,20,21,31]' You will not see any decimals, values above 40, or negative numbers
// This is the native slither skin code - it is not in the NTL color code format yet. This happens in this script.
// It will also be a generally shorter array than others. This is your skin variable.
//***************************************************************************************************************************************

    if (window.bn) {
// Change here ^^^ GLOBAL WINDOW OBJECT CONTAINING PLAYER ID'S************************************

        // Get all property names of the gn object
        keys = Object.keys(window.bn);
				   // Change here ^^^ GLOBAL WINDOW OBJECT CONTAINING PLAYER ID'S************************************
        console.log(window.bn);
            // Change here ^^^ GLOBAL WINDOW OBJECT CONTAINING PLAYER ID'S************************************

        // Loop through each property name
        newPlayersArray.length = 0;
        playerDataArray.length = 0;
        keys.forEach(key => {
            // Access the nested object using the property name
            let nestedObject = window.bn[key];
			    // Change here ^^^ GLOBAL WINDOW OBJECT CONTAINING PLAYER ID'S************************************

            // Check if the nested object has an ID property
            if (nestedObject.hasOwnProperty('id')) {
                let newPlayersArray = [];

                newPlayersArray.push(nestedObject.ssn);
				                  // Change here  ^^^ IGN VARIABLE GOES HERE ******************************************

                keyList = nestedObject.BA;
				       // Change here  ^^^ SKIN ARRAY GOES HERE ******************************************


                console.log(keyList);
                //console.log("Key list", keyList);
                skinString = "";
                for (var ii = 0; ii < keyList.length; ii++){
                    dictKeys = keyList[ii];
                    value = skin_dict[dictKeys];

                    skinString += value[0];
                }
                newPlayersArray.push(skinString);
                playerDataArray.push(newPlayersArray);
                addToDictionary(newPlayersArray[0], newPlayersArray[1]);
            }
        });
        //document.body.appendChild(newDiv);
        document.getElementById("PlayerDataDivWrapper").style.visibility = "visible";
        document.getElementById("PlayerDataDivWrapper").innerHTML = PlayerDataDivWrapperInnerHTML;
        let i=0;
        let playerDataHTML = "";
        for (i=0; i < playerDataArray.length; i++) {
            if(playerDataArray[i][0]){

                if(playerDataArray[i][0] != snake.ssn){
					              // Change here  ^^^ IGN VARIABLE GOES HERE ******************************************

                    console.log(playerDataArray[i][0],snake.ssn);
                    addBreak = true;
            playerDataHTML += "<span class='snakeName'>" + playerDataArray[i][0].toString() + "</span>: ";
                    //playerDataArray[i].pop();
                }
            }
            if(playerDataArray[i][1]){

                if(playerDataArray[i][0] != snake.ssn){
					              // Change here  ^^^ IGN VARIABLE GOES HERE ******************************************

                    addBreak = true;
            playerDataHTML += "<span class='snakeSkin'>" + playerDataArray[i][1].toString() + "</span>";
                    //playerDataArray[i][0].pop();
                }
            }
            if (addBreak){
                pageClearCounter++
                addBreak = false;
            playerDataHTML += "<br>";
            }
            function showAndHideText() {
  // Show the text
  document.getElementById('ShowHideText').style.display = 'block';

  // Hide the text after 2 seconds
  setTimeout(function() {
    document.getElementById('ShowHideText').style.display = 'none';
  }, 3000); // 3000 milliseconds = 3 seconds
}
            showAndHideText()
        }
    }
}

// Hide Page when clicked
//skinlogHider.addEventListener("click", function (){
//    nameAndSkinWrapper.style.visibility = "hidden";
//});


const SHOW_DIV_KEY = ";";
const KEYSPEED = 500;
let show_div = false;
let semicolonPressCount = 0;

const CAPTURE_KEY = "y";
const CLEAR_KEY = "`";

//createPlayerSkinPage()
document.addEventListener("keydown", function onEvent(event) {
  var nameAndSkinWrapper = document.getElementById("nameAndSkinWrapper");

  if (event.key === CAPTURE_KEY) {
    getAndDisplayPlayerData();
  }

  if (event.key === CLEAR_KEY) {
    clearSkinDataDiv();
  }

  if (event.key === SHOW_DIV_KEY) {
    semicolonPressCount++;

    if (semicolonPressCount === 2 && !show_div) {
      createPlayerSkinPage();
      nameAndSkinWrapper.style.visibility = "visible";
      show_div = true;
      console.log(show_div, "First if statement");
    } else if (semicolonPressCount === 2 && show_div) {
      console.log("show_div true, in 2nd if statement");
      nameAndSkinWrapper.style.visibility = "hidden";
      show_div = false;
      console.log(show_div, nameAndSkinWrapper);
    }

    // Reset the semicolon press count after a short delay
    setTimeout(function() {
      semicolonPressCount = 0;
    }, KEYSPEED);
  }
});



// THIS BEGINS AUTOMATION CODE - 1000 is milliseconds - change to your desire.
// REMOVE DOUBLE FORWARD SLASHES FROM CODE BELOW TO RUN SCRIPT HANDS FREE.
// INCOG WITH SIMPLE NAME RECOMENDED AS CAPTURES WILL FILL SCREEN, CAN INDUCE LAG, AND MAKES PLAYING WITH SKILL DIFFICULT.

//let newInterval = 1000;
//setInterval(getAndDisplayPlayerData, newInterval);


})();