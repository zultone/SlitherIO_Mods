
  // Create a draggable div
  const draggableDiv = document.createElement('div');
  draggableDiv.style.position = 'fixed';
  draggableDiv.style.top = '35%';
  draggableDiv.style.left = '85%';
  draggableDiv.style.transform = 'translate(-50%, -50%)';
  draggableDiv.style.width = '275px';
  draggableDiv.style.height = '400px';
  draggableDiv.style.background = 'rgba(255, 255, 255, 0)';
  draggableDiv.style.border = '1px solid black';
  draggableDiv.style.zIndex = '9999';
  draggableDiv.style.cursor = 'move';
  draggableDiv.style.color = 'magenta';

  // Collapse/Expand link
  const collapseExpandLink = document.createElement('a');
  collapseExpandLink.textContent = 'Collapse';
  collapseExpandLink.style.display = 'block';
  collapseExpandLink.style.textAlign = 'center';
  collapseExpandLink.style.marginBottom = '10px';
  collapseExpandLink.style.color = 'magenta';
  collapseExpandLink.style.textDecoration = 'underline';
  collapseExpandLink.style.cursor = 'pointer';

  // Iframe
  const iframe = document.createElement('iframe');
  iframe.src = 'http://cursedslither.pythonanywhere.com/';
  iframe.style.width = '100%';
  iframe.style.height = 'calc(100% - 50px)';
  iframe.style.border = 'none';
  iframe.style.margin = 'auto';
  iframe.style.display = 'block';

  // Append elements to the draggable div
  draggableDiv.appendChild(collapseExpandLink);
  draggableDiv.appendChild(iframe);

  // Add the draggable div to the document body
  document.body.appendChild(draggableDiv);

  // Make the div draggable
  let isDragging = false;
  let startPosition = { x: 0, y: 0 };

  draggableDiv.addEventListener('mousedown', function(event) {
    isDragging = true;
    startPosition.x = event.clientX - draggableDiv.offsetLeft;
    startPosition.y = event.clientY - draggableDiv.offsetTop;
  });

  draggableDiv.addEventListener('mousemove', function(event) {
    if (isDragging) {
      const newX = event.clientX - startPosition.x;
      const newY = event.clientY - startPosition.y;
      draggableDiv.style.left = newX + 'px';
      draggableDiv.style.top = newY + 'px';
    }
  });

  draggableDiv.addEventListener('mouseup', function() {
    isDragging = false;
  });

  // Collapse/Expand functionality
  let isCollapsed = false;

  function toggleCollapseExpand() {
    if (isCollapsed) {
      iframe.style.display = 'block';
      collapseExpandLink.textContent = 'Collapse';
      isCollapsed = false;
    } else {
      iframe.style.display = 'none';
      collapseExpandLink.textContent = 'Expand';
      isCollapsed = true;
    }
  }

  collapseExpandLink.addEventListener('click', toggleCollapseExpand);


